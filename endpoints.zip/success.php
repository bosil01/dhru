<?php
echo "<h1>Paiement réussi !</h1>";
echo "<p>Votre paiement a été traité avec succès.</p>";
echo "<p>Vous allez être redirigé...</p>";
// Redirection vers Dhru Fusion Pro si nécessaire
?>
