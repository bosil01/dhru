<?php
$apiKeys = [
    '8a35d9c4e2ccbd484cee94517806624c741cde76659a52d356f1a187f27d2c6a', // Votre clé pour Dhru
    'mo9soKo2vGD8hx6fp5XCl6qXmO93BDTi', // Clé Orange Money
];
