<?php
// Fichier de base pour recevoir les notifications Orange Money
require_once 'api_keys.php';
require_once 'database.php';
require_once 'OrderModel.php';

// Log de la notification reçue
error_log("=== NOTIFICATION ORANGE MONEY REÇUE ===");
error_log("POST: " . json_encode($_POST));
error_log("Raw input: " . file_get_contents('php://input'));

// Répondre 200 OK à Orange Money
http_response_code(200);
echo "OK";
?>
