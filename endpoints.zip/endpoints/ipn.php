<?php

require_once __DIR__ . '/../config/api_keys.php';
require_once __DIR__ . '/../core/common.php';
require_once __DIR__ . '/../core/OrderModel.php';
require_once __DIR__ . '/../core/OrangeMoneyPayment.php';

validateApiKey();
$input = getValidatedInput();

$order_id = $input['order_id'] ?? null;
$notif_token = $input['notif_token'] ?? null;

if (!$order_id || !$notif_token) {
    output('error', 'Invalid IPN parameters.', null, 400);
}

$orderModel = new OrderModel();
$order = $orderModel->getOrderById($order_id);
if (!$order) {
    output('error', 'Order not found!', null, 404);
}

$orangeMoney = new OrangeMoneyPayment();
if (!$orangeMoney->verifyIpnNotifToken($notif_token, $order['notif_token'])) {
    output('error', 'Invalid notif_token', null, 400);
}

$statusData = $orangeMoney->getTransactionStatus($order['custom_id'], $order['amount'], $order['pay_token']);
$order_status = $statusData['status'] ?? 'UNKNOWN';
$orderModel->updateOrder($order_id, [
    'status'         => $order_status,
    'transaction_id' => $statusData['txnid'] ?? null
]);

if ($order_status === 'SUCCESS') {
    $ipn_result = sendIpnDetailsToDhruFusion($order['ipn_url'], $order_id);
}

output('success', 'IPN processed successfully.');