<?php
/**
 * Point d'entrée pour les requêtes de paiement depuis Dhru Fusion Pro
 * Version finale optimisée avec toutes les corrections
 * Gère la conversion automatique USD → GNF pour Orange Money Guinée
 * Compatible iframe avec redirection target="_top"
 */

// Configuration sécurisée pour la production
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Headers de sécurité
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Strict-Transport-Security: max-age=31536000; includeSubDomains');

// Inclure les fichiers nécessaires
require_once __DIR__ . '/../api_keys.php';
require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/../OrderModel.php';
require_once __DIR__ . '/../OrangeMoneyPayment.php';

// Configuration des constantes
define('USD_TO_GNF_RATE', 1000);
define('MIN_AMOUNT_GNF', 500);
define('MAX_AMOUNT_GNF', 5000000);
define('MAX_INPUT_SIZE', 10240); // 10KB max pour les données d'entrée

/**
 * Polyfill pour str_contains (PHP 8+)
 */
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle !== '' && strpos($haystack, $needle) !== false;
    }
}

/**
 * Fonction de conversion USD vers GNF
 */
function convertUsdToGnf($amountUsd) {
    return round($amountUsd * USD_TO_GNF_RATE, 0);
}

/**
 * Fonction de validation sécurisée
 */
function validateAndSanitizeInput($input, $type = 'string', $maxLength = 255) {
    switch ($type) {
        case 'email':
            return filter_var($input, FILTER_VALIDATE_EMAIL) ?: null;
        case 'url':
            return filter_var($input, FILTER_VALIDATE_URL) ?: null;
        case 'int':
            return filter_var($input, FILTER_VALIDATE_INT) ?: 0;
        case 'float':
            return filter_var($input, FILTER_VALIDATE_FLOAT) ?: 0.0;
        case 'string':
        default:
            $sanitized = filter_var($input, FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_HIGH);
            return substr($sanitized, 0, $maxLength);
    }
}

// Validation de la clé API avec protection contre les attaques de timing
global $apiKeys;
$headers = getallheaders();
$apiKey = $headers['X-Api-Key'] ?? $headers['X-API-KEY'] ?? null;

$validKey = false;
if ($apiKey) {
    foreach ($apiKeys as $validApiKey) {
        if (hash_equals($validApiKey, $apiKey)) {
            $validKey = true;
            break;
        }
    }
}

if (!$validKey) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized: Invalid API Key.',
        'error_code' => 'INVALID_API_KEY'
    ]);
    exit;
}

// Validation CSRF basique pour les domaines autorisés
$allowedOrigins = [
    'https://gsmeasytech.dhrufusion.in',
    'https://gsmeasytech.dhrufusion.net',
    'https://tty.yqp.mybluehost.me'
];

$actualOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($actualOrigin && !in_array($actualOrigin, $allowedOrigins)) {
    error_log("⚠️ CSRF Warning: Origin non autorisé - " . $actualOrigin);
}

// Récupération sécurisée des données
$postData = $_POST;
$getData = $_GET;
$rawInput = file_get_contents('php://input', false, null, 0, MAX_INPUT_SIZE);
$jsonInput = json_decode($rawInput, true, 10); // Limite de profondeur JSON

// Debug sécurisé (sans données sensibles)
error_log("=== ORANGE MONEY PAYMENT REQUEST ===");
error_log("Method: " . ($_SERVER['REQUEST_METHOD'] ?? 'unknown'));
error_log("Content-Type: " . ($_SERVER['CONTENT_TYPE'] ?? 'unknown'));
error_log("Accept: " . ($_SERVER['HTTP_ACCEPT'] ?? 'unknown'));
error_log("Origin: " . ($actualOrigin ?: 'none'));
error_log("User-Agent: " . substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 100));

// Déterminer la source de données avec priorité sécurisée
$input = [];
if (!empty($jsonInput) && is_array($jsonInput)) {
    $input = $jsonInput;
    error_log("Source: JSON input");
} elseif (!empty($postData)) {
    $input = $postData;
    error_log("Source: POST data");
} elseif (!empty($getData)) {
    $input = $getData;
    error_log("Source: GET parameters");
} else {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error', 
        'message' => 'No valid data received',
        'error_code' => 'NO_DATA'
    ]);
    exit;
}

// Validation et sanitisation des champs requis
$requiredFields = ['amount', 'custom_id'];
$missingFields = [];

foreach ($requiredFields as $field) {
    if (empty($input[$field])) {
        $missingFields[] = $field;
    }
}

if (!empty($missingFields)) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error', 
        'message' => 'Missing required fields: ' . implode(', ', $missingFields),
        'error_code' => 'MISSING_FIELDS',
        'missing_fields' => $missingFields
    ]);
    exit;
}

// Validation et conversion sécurisée des montants
$amountUsd = validateAndSanitizeInput($input['amount'], 'float');
if ($amountUsd <= 0 || $amountUsd > 10000) { // Limite raisonnable
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error', 
        'message' => 'Invalid amount: must be between 0.01 and 10,000 USD',
        'error_code' => 'INVALID_AMOUNT'
    ]);
    exit;
}

$amountGnf = convertUsdToGnf($amountUsd);

// Validation des limites Orange Money Guinée
if ($amountGnf < MIN_AMOUNT_GNF || $amountGnf > MAX_AMOUNT_GNF) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error', 
        'message' => sprintf(
            'Amount out of Orange Money limits: %s GNF (min: %s, max: %s)',
            number_format($amountGnf),
            number_format(MIN_AMOUNT_GNF),
            number_format(MAX_AMOUNT_GNF)
        ),
        'error_code' => 'AMOUNT_OUT_OF_LIMITS',
        'limits' => [
            'min_gnf' => MIN_AMOUNT_GNF,
            'max_gnf' => MAX_AMOUNT_GNF,
            'current_gnf' => $amountGnf
        ]
    ]);
    exit;
}

error_log("💰 Montant validé: $amountUsd USD = " . number_format($amountGnf) . " GNF");

try {
    // Création sécurisée de la commande
    $orderModel = new OrderModel();
    
    // Sanitisation et validation de toutes les données d'entrée
    $orderData = [
        'amount'        => $amountUsd,
        'amount_gnf'    => $amountGnf,
        'currency_code' => 'USD',
        'currency_om'   => 'GNF',
        'exchange_rate' => USD_TO_GNF_RATE,
        'description'   => validateAndSanitizeInput($input['description'] ?? 'Service Dhru Fusion Pro', 'string', 500),
        'customer_name' => validateAndSanitizeInput($input['customer_name'] ?? 'Client', 'string', 100),
        'customer_email'=> validateAndSanitizeInput($input['customer_email'] ?? 'client@example.com', 'email') ?: 'client@example.com',
        'custom_id'     => validateAndSanitizeInput($input['custom_id'], 'string', 50),
        'ipn_url'       => validateAndSanitizeInput($input['ipn_url'] ?? '', 'url'),
        'success_url'   => validateAndSanitizeInput($input['success_url'] ?? '', 'url'),
        'fail_url'      => validateAndSanitizeInput($input['fail_url'] ?? '', 'url'),
        'order_date'    => date('Y-m-d H:i:s'),
        'user_ip'       => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent'    => substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 255),
        'referrer'      => substr($_SERVER['HTTP_REFERER'] ?? 'direct', 0, 255)
    ];
    
    $orderId = $orderModel->createOrder($orderData);
    
    if ($orderId) {
        // Génération d'un order_id unique avec entropie renforcée
        $timestamp = substr(time(), -6);
        $randomSuffix = str_pad(mt_rand(100, 999), 3, '0', STR_PAD_LEFT);
        $orange_order_id = $orderData['custom_id'] . $timestamp . $randomSuffix;
        
        // Données sécurisées pour Orange Money
        $orangeData = [
            'amount'        => $amountGnf,
            'currency_code' => 'GNF',
            'custom_id'     => $orange_order_id,
            'description'   => $orderData['description'],
            'customer_name' => $orderData['customer_name'],
            'customer_email'=> $orderData['customer_email'],
            'success_url'   => $orderData['success_url'] ?: ($_SERVER['HTTP_REFERER'] ?? ''),
            'fail_url'      => $orderData['fail_url'] ?: ($_SERVER['HTTP_REFERER'] ?? ''),
        ];
        
        error_log("🔢 Order ID unique généré: " . $orange_order_id);
        error_log("📊 Order DB ID: " . $orderId);
        
        // Appel Orange Money avec retry logic
        $orangeMoney = new OrangeMoneyPayment();
        $maxRetries = 3;
        $payment = null;
        $lastError = null;
        
        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            try {
                error_log("🔄 Tentative $attempt/$maxRetries vers Orange Money API");
                $payment = $orangeMoney->createPayment($orangeData);
                error_log("✅ Succès Orange Money API à la tentative $attempt");
                break; // Succès, sortir de la boucle
                
            } catch (Exception $e) {
                $lastError = $e;
                error_log("⚠️ Tentative $attempt échouée: " . $e->getMessage());
                
                if ($attempt === $maxRetries) {
                    throw $e; // Dernière tentative, propager l'erreur
                }
                
                // Attendre avant de réessayer (backoff exponentiel)
                sleep($attempt);
            }
        }
        
        // Sauvegarder les données de manière sécurisée (sans api_response pour éviter l'erreur de colonne)
        $updateResult = $orderModel->updateOrder($orderId, [
            'pay_token'   => $payment['pay_token'],
            'notif_token' => $payment['notif_token'],
            'order_id_om' => $orange_order_id,
            'status'      => 'pending_payment'
        ]);
        
        if (!$updateResult) {
            error_log("⚠️ Échec de mise à jour de la commande ID: $orderId");
        }
        
        $redirectUrl = $payment['checkout_url'];
        
        error_log("🎯 SUCCÈS ORANGE MONEY");
        error_log("URL de redirection: " . $redirectUrl);
        error_log("Pay Token: " . substr($payment['pay_token'], 0, 20) . '...');
        
        /* ================================================================
         *  DÉTECTION DU TYPE DE REQUÊTE : JSON vs HTML
         *  ---- CORRECTION PRINCIPALE POUR DHRU FUSION PRO ----
         * ================================================================ */
        
        // Détection basée sur le header Accept (plus fiable que User-Agent)
        $acceptHeader = $_SERVER['HTTP_ACCEPT'] ?? '';
        $wantsJson = str_contains($acceptHeader, 'application/json');
        
        // Log pour debug
        error_log("🔍 Accept Header: " . $acceptHeader);
        error_log("🎯 Wants JSON: " . ($wantsJson ? 'YES' : 'NO'));
        
      if ($wantsJson) {
    /* ============================================================
     *  BRANCHE JSON : Pour les appels serveur-à-serveur de Dhru
     * ============================================================ */
    error_log("📤 Réponse JSON pour Dhru Fusion Pro");

    // ✅ Format attendu par le frontend pour déclencher la redirection
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'status'     => 'success',                      // ✅ Changement clé ici
        'url'        => $redirectUrl,                   // ✅ URL directe de paiement Orange
        'pay_token'  => $payment['pay_token'] ?? null,  // 🔒 Facultatif pour tracking ou IPN
        'order_id'   => $orderData['custom_id']         // 📦 Utile pour ton affichage final
    ], JSON_UNESCAPED_SLASHES);
    exit;



            
            exit; // Terminer ici pour les requêtes JSON
            
        } else {
            /* ============================================================
             *  BRANCHE HTML : Pour les iframes du navigateur
             * ============================================================ */
            error_log("📄 Réponse HTML pour iframe du navigateur");
            
            // Réponse HTML avec redirection target="_top" pour iframe
            echo '<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirection Orange Money</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; 
            text-align: center; 
            padding: 50px; 
            background: linear-gradient(135deg, #ff6b35, #f7931e);
            color: white;
            margin: 0;
        }
        .container {
            background: white;
            color: #333;
            padding: 40px;
            border-radius: 15px;
            display: inline-block;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            max-width: 400px;
        }
        .logo {
            width: 60px;
            height: 60px;
            background: #ff6b35;
            border-radius: 50%;
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            font-weight: bold;
        }
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #ff6b35;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .amount {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 4px solid #ff6b35;
            font-size: 16px;
            font-weight: bold;
        }
        .redirect-btn {
            background: #ff6b35;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .redirect-btn:hover {
            background: #e55a2b;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">OM</div>
        <h2>🟠 Redirection Orange Money</h2>
        <div class="amount">' . number_format($amountGnf, 0, ',', ' ') . ' GNF</div>
        <div class="spinner"></div>
        <p>Redirection automatique en cours...</p>
        
        <!-- Formulaire avec target="_top" pour sortir de l\'iframe -->
        <form id="redirectForm" action="' . htmlspecialchars($redirectUrl, ENT_QUOTES, 'UTF-8') . '" method="GET" target="_top">
            <button type="submit" class="redirect-btn">
                🚀 Continuer vers Orange Money
            </button>
        </form>
        
        <p><small>Commande #' . htmlspecialchars($orderData['custom_id'], ENT_QUOTES, 'UTF-8') . '</small></p>
    </div>
    
    <script>
        (function() {
            "use strict";
            
            var orangeUrl = ' . json_encode($redirectUrl, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';
            var form = document.getElementById("redirectForm");
            var redirected = false;
            
            function performRedirect() {
                if (redirected) return;
                redirected = true;
                
                console.log("🎯 Redirection Orange Money:", orangeUrl);
                
                try {
                    // Méthode 1: Soumettre le formulaire avec target="_top"
                    form.submit();
                    
                    // Méthode 2: Fallback JavaScript après 2 secondes
                    setTimeout(function() {
                        try {
                            if (window.top && window.top !== window) {
                                window.top.location.href = orangeUrl;
                            } else {
                                window.location.href = orangeUrl;
                            }
                        } catch (e) {
                            window.location.href = orangeUrl;
                        }
                    }, 2000);
                    
                } catch (e) {
                    console.error("Erreur redirection:", e);
                    window.location.href = orangeUrl;
                }
            }
            
            // Redirection automatique après 1 seconde
            setTimeout(performRedirect, 1000);
            
            // Redirection sur clic
            document.addEventListener("click", performRedirect);
            
        })();
    </script>
</body>
</html>';
            
            exit; // Terminer ici pour les requêtes HTML
        }
        
    } else {
        throw new Exception('Échec de création de commande en base de données');
    }
    
} catch (Exception $e) {
    error_log("❌ ERREUR CRITIQUE: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    error_log("Input data: " . json_encode($input, JSON_UNESCAPED_SLASHES));
    
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error', 
        'message' => 'Une erreur est survenue lors du traitement du paiement. Veuillez réessayer.',
        'error_code' => 'PAYMENT_PROCESSING_ERROR',
        'timestamp' => date('c'),
        'order_id' => $orderId ?? null
    ], JSON_UNESCAPED_SLASHES);
}
?>
