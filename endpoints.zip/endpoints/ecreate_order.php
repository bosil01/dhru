<?php
/**
 * Point d'entrée pour les requêtes de paiement depuis Dhru Fusion Pro
 * Gère la conversion automatique USD → GNF pour Orange Money Guinée
 */

// Debug activé
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Inclure les fichiers nécessaires
require_once __DIR__ . '/../api_keys.php';
require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/../OrderModel.php';
require_once __DIR__ . '/../OrangeMoneyPayment.php';

// Configuration des taux de change USD → GNF
define('USD_TO_GNF_RATE', 1000);

function convertUsdToGnf($amountUsd) {
    return round($amountUsd * USD_TO_GNF_RATE, 0);
}

// Validation de la clé API
global $apiKeys;
$headers = getallheaders();
$apiKey = $headers['X-Api-Key'] ?? $headers['X-API-KEY'] ?? null;

if (!$apiKey || !in_array($apiKey, $apiKeys)) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized: Invalid API Key.']);
    exit;
}

// Récupération des données (Dhru envoie en JSON, pas en POST)
$postData = $_POST;
$getData = $_GET;
$rawInput = file_get_contents('php://input');
$jsonInput = json_decode($rawInput, true);

// Debug complet
error_log("=== DEBUG DONNÉES REÇUES ===");
error_log("POST data: " . json_encode($postData));
error_log("GET data: " . json_encode($getData));
error_log("Raw input: " . $rawInput);
error_log("JSON decoded: " . json_encode($jsonInput));

// Déterminer quelle source utiliser
$input = [];
if (!empty($postData)) {
    $input = $postData;
} elseif (!empty($jsonInput)) {
    $input = $jsonInput;
} elseif (!empty($getData)) {
    $input = $getData;
} else {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'No data received from Dhru Fusion Pro']);
    exit;
}

// Vérification des champs requis
if (empty($input['amount']) || empty($input['custom_id'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error', 
        'message' => 'Missing required parameters: amount or custom_id',
        'received_data' => $input
    ]);
    exit;
}

// Conversion automatique USD → GNF
$amountUsd = floatval($input['amount']);
$amountGnf = convertUsdToGnf($amountUsd);

error_log("Conversion: $amountUsd USD = $amountGnf GNF");

try {
    // Création de la commande avec conversion
    $orderModel = new OrderModel();
    $orderData = [
        'amount'        => $amountUsd,                    // Montant original USD
        'amount_gnf'    => $amountGnf,                    // Montant converti GNF
        'currency_code' => 'USD',                         // Devise originale
        'currency_om'   => 'GNF',                         // Devise Orange Money
        'exchange_rate' => USD_TO_GNF_RATE,               // Taux utilisé
        'description'   => $input['description'] ?? 'Paiement Dhru',
        'customer_name' => $input['customer_name'] ?? 'Client',
        'customer_email'=> $input['customer_email'] ?? 'client@example.com',
        'custom_id'     => $input['custom_id'],
        'ipn_url'       => $input['ipn_url'] ?? '',
        'success_url'   => $input['success_url'] ?? '',
        'fail_url'      => $input['fail_url'] ?? '',
        'order_date'    => date('Y-m-d H:i:s'),
    ];
    
    $orderId = $orderModel->createOrder($orderData);
    
    if ($orderId) {
        // Préparer les données pour Orange Money (en GNF)
        $orangeData = [
            'amount'        => $amountGnf,                // Montant en GNF
            'currency_code' => 'GNF',                     // Devise GNF
            'custom_id'     => $input['custom_id'],
            'description'   => $input['description'] ?? 'Paiement Dhru',
            'customer_name' => $input['customer_name'] ?? 'Client',
            'customer_email'=> $input['customer_email'] ?? 'client@example.com',
            'success_url'   => $input['success_url'] ?? '',
            'fail_url'      => $input['fail_url'] ?? '',
        ];
        
        error_log("Données envoyées à Orange Money: " . json_encode($orangeData));
        
        // Appel à Orange Money
        $orangeMoney = new OrangeMoneyPayment();
        $payment = $orangeMoney->createPayment($orangeData);
        
        $orderModel->updateOrder($orderId, [
            'pay_token'   => $payment['pay_token'],
            'notif_token' => $payment['notif_token']
        ]);
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Order created successfully!',
            'type' => 'url',
            'url' => $payment['checkout_url'],
            'amount_usd' => $amountUsd,
            'amount_gnf' => $amountGnf,
            'exchange_rate' => USD_TO_GNF_RATE
        ]);
    } else {
        throw new Exception('Failed to create order in database.');
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error', 
        'message' => $e->getMessage(),
        'debug_info' => [
            'amount_usd' => $amountUsd ?? 'not set',
            'amount_gnf' => $amountGnf ?? 'not set',
            'input_data' => $input
        ]
    ]);
}
?>
