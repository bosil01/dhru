<?php
/**
 * Point d'entrée pour les requêtes de paiement depuis Dhru Fusion Pro
 * VERSION SANDBOX - Gère la conversion automatique USD → OUV pour Orange Money Test
 */

// Debug activé pour SANDBOX
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json');

// Inclure les fichiers nécessaires
require_once __DIR__ . '/../api_keys.php';
require_once __DIR__ . '/../common.php';
require_once __DIR__ . '/../OrderModel.php';
require_once __DIR__ . '/../OrangeMoneyPayment.php';

// Configuration des taux de change USD → OUV pour SANDBOX
define('USD_TO_OUV_RATE', 1); // Taux fictif pour les tests
define('ENVIRONMENT', 'sandbox'); // Mode test

function convertUsdToOuv($amountUsd) {
    return round($amountUsd * USD_TO_OUV_RATE, 0);
}

// Validation de la clé API
global $apiKeys;
$headers = getallheaders();
$apiKey = $headers['X-Api-Key'] ?? $headers['X-API-KEY'] ?? null;

if (!$apiKey || !in_array($apiKey, $apiKeys)) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized: Invalid API Key.']);
    exit;
}

// Récupération des données (Dhru envoie en JSON)
$postData = $_POST;
$getData = $_GET;
$rawInput = file_get_contents('php://input');
$jsonInput = json_decode($rawInput, true);

// Debug complet pour SANDBOX
error_log("=== DEBUG DONNÉES REÇUES SANDBOX ===");
error_log("POST data: " . json_encode($postData));
error_log("GET data: " . json_encode($getData));
error_log("Raw input: " . $rawInput);
error_log("JSON decoded: " . json_encode($jsonInput));
error_log("Environment: " . ENVIRONMENT);

// Déterminer quelle source utiliser
$input = [];
if (!empty($postData)) {
    $input = $postData;
    error_log("Utilisation des données POST");
} elseif (!empty($jsonInput)) {
    $input = $jsonInput;
    error_log("Utilisation des données JSON");
} elseif (!empty($getData)) {
    $input = $getData;
    error_log("Utilisation des données GET");
} else {
    http_response_code(400);
    echo json_encode([
        'status' => 'error', 
        'message' => 'No data received from Dhru Fusion Pro',
        'environment' => ENVIRONMENT
    ]);
    exit;
}

// Vérification des champs requis
if (empty($input['amount']) || empty($input['custom_id'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error', 
        'message' => 'Missing required parameters: amount or custom_id',
        'received_data' => $input,
        'environment' => ENVIRONMENT
    ]);
    exit;
}

// Conversion automatique USD → OUV pour SANDBOX
$amountUsd = floatval($input['amount']);
$amountOuv = convertUsdToOuv($amountUsd);

error_log("Conversion SANDBOX: $amountUsd USD = $amountOuv OUV (taux: " . USD_TO_OUV_RATE . ")");

try {
    // Création de la commande avec conversion SANDBOX
    $orderModel = new OrderModel();
    $orderData = [
        'amount'        => $amountUsd,                    // Montant original USD
        'amount_gnf'    => $amountOuv,                    // Montant converti OUV (réutilise la colonne)
        'currency_code' => 'USD',                         // Devise originale
        'currency_om'   => 'OUV',                         // Devise Orange Money SANDBOX
        'exchange_rate' => USD_TO_OUV_RATE,               // Taux utilisé pour SANDBOX
        'description'   => $input['description'] ?? 'Paiement Dhru SANDBOX',
        'customer_name' => $input['customer_name'] ?? 'Client Test',
        'customer_email'=> $input['customer_email'] ?? 'test@example.com',
        'custom_id'     => $input['custom_id'],
        'ipn_url'       => $input['ipn_url'] ?? '',
        'success_url'   => $input['success_url'] ?? '',
        'fail_url'      => $input['fail_url'] ?? '',
        'order_date'    => date('Y-m-d H:i:s'),
        'status'        => 'pending_sandbox', // Statut spécial pour SANDBOX
    ];
    
    $orderId = $orderModel->createOrder($orderData);
    
    if ($orderId) {
        // Préparer les données pour Orange Money SANDBOX (en OUV)
        $orangeData = [
            'amount'        => $amountOuv,                // Montant en OUV
            'currency_code' => 'OUV',                     // Devise SANDBOX
            'custom_id'     => $input['custom_id'],
            'description'   => $input['description'] ?? 'Paiement Dhru SANDBOX',
            'customer_name' => $input['customer_name'] ?? 'Client Test',
            'customer_email'=> $input['customer_email'] ?? 'test@example.com',
            'success_url'   => $input['success_url'] ?? '',
            'fail_url'      => $input['fail_url'] ?? '',
        ];
        
        error_log("=== DONNÉES ENVOYÉES À ORANGE MONEY SANDBOX ===");
        error_log("Merchant Key: 4c22404e");
        error_log("Devise: OUV (Test)");
        error_log("Montant: $amountOuv OUV");
        error_log("Données complètes: " . json_encode($orangeData));
        
        // Appel à Orange Money SANDBOX
        $orangeMoney = new OrangeMoneyPayment();
        $payment = $orangeMoney->createPayment($orangeData);
        
        // Mettre à jour la commande avec les tokens Orange Money
        $orderModel->updateOrder($orderId, [
            'pay_token'   => $payment['pay_token'],
            'notif_token' => $payment['notif_token'],
            'status'      => 'payment_initiated_sandbox'
        ]);
        
        // Réponse de succès à Dhru Fusion Pro
        echo json_encode([
            'status' => 'success',
            'message' => 'SANDBOX Order created successfully!',
            'type' => 'url',
            'url' => $payment['checkout_url'],
            'environment' => ENVIRONMENT,
            'amount_usd' => $amountUsd,
            'amount_ouv' => $amountOuv,
            'exchange_rate' => USD_TO_OUV_RATE,
            'merchant_key' => '4c22404e',
            'currency_test' => 'OUV',
            'order_id' => $orderId,
            'pay_token' => $payment['pay_token']
        ]);
        
        error_log("=== SUCCÈS SANDBOX ===");
        error_log("Order ID: $orderId");
        error_log("Pay Token: " . $payment['pay_token']);
        error_log("URL de paiement: " . $payment['checkout_url']);
        
    } else {
        throw new Exception('Failed to create order in database.');
    }
    
} catch (Exception $e) {
    error_log("=== ERREUR SANDBOX ===");
    error_log("Message: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'status' => 'error', 
        'message' => 'SANDBOX Error: ' . $e->getMessage(),
        'environment' => ENVIRONMENT,
        'debug_info' => [
            'amount_usd' => $amountUsd ?? 'not set',
            'amount_ouv' => $amountOuv ?? 'not set',
            'input_data' => $input,
            'merchant_key' => '4c22404e',
            'currency' => 'OUV',
            'api_base' => 'https://api.orange.com/orange-money-webpay/dev/v1'
        ]
    ]);
}
?>
